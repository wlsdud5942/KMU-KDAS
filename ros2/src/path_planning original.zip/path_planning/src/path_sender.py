#!/usr/bin/env python3
import sys
import os
import json
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from std_msgs.msg import String, Bool, Int32, Float32MultiArray, MultiArrayDimension


# locate package resources
full_path = os.path.join(os.getcwd(), "ros2/src/path_planning")
sys.path.append(os.path.join(full_path, "src"))

from waypoint_interpolator import interpolate_path
from area_checker import check_area

class PathSenderNode(Node):
    def __init__(self):
        super().__init__('path_sender')
        
        # Publisher for planned path'
        self.path_pub_x = self.create_publisher(Float32MultiArray, 'path_x', 10)
        self.path_pub_y = self.create_publisher(Float32MultiArray, 'path_y', 10)

        # Subscribers
        self.create_subscription(Point, 'location', self.location_callback, 10)
        self.create_subscription(Float32MultiArray, '/lane_detection/waypoints_x', self.center_x_callback, 10)
        self.create_subscription(Float32MultiArray, '/lane_detection/waypoints_y', self.center_y_callback, 10)
        self.create_subscription(Int32, '/lane_detection/lane_state',self.state_callback , 10)
        self.create_subscription(String, '/detection_label', self.detection_label_callback, 10)
        self.create_subscription(Bool, '/stop', self.object_detected_callback, 10)

        # Number of Waypoints
        self.TARGET_N = 30

        # Data containers
        self.current_pos = (0.0, 0.0)
        self.center_x = []
        self.center_y = []
        self.detection_label = ''
        self.object_detected = False
        self.lane_state = 0
        self.current_path = []
        self.current_index = 0

        # Directory for per-area JSON waypoint files
        self.config_dir = os.path.join(full_path, 'config')
        self.corner_1_pass_count = 0
        self.previous_area = 'none'

        self.get_logger().info("Path Sender up & running")
        # Main loop timer
        self.create_timer(0.5, self.loop)

    def load_waypoints(self, filepath):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except Exception as e:
            self.get_logger().fatal(f"Failed to load waypoints from {filepath}: {e}")
            rclpy.shutdown()

    def location_callback(self, msg: Point):
        self.current_pos = (msg.x, msg.y)

    def center_x_callback(self, msg: Float32MultiArray):
        self.center_x = msg.data

    def center_y_callback(self, msg: Float32MultiArray):
        self.center_y = msg.data

    def state_callback(self, msg: Int32):
        self.lane_state = msg.data

    def detection_label_callback(self, msg: String):
        self.detection_label = msg.data        

    def object_detected_callback(self, msg: Bool):
        self.object_detected = msg.data

    def publish_path(self):
        if not self.current_path:
            self.get_logger().warn("No path to publish.")
            return

        if self.current_index + 30 > len(self.current_path):
            self.get_logger().info("Not enough points left to publish a batch of 30. Skipping.")
            return

        # Get the next 30 points
        points_to_publish = self.current_path[self.current_index:self.current_index + 4]
        x_list = [p[0] for p in points_to_publish]
        y_list = [p[1] for p in points_to_publish]

        msgx = Float32MultiArray()
        msgy = Float32MultiArray()
        msgx.data = x_list
        msgy.data = y_list

        self.path_pub_x.publish(msgx)
        self.path_pub_y.publish(msgy)

        self.get_logger().info(f"Published 4 points starting from index {self.current_index}")

        # Update index
        self.current_index += 1


    def loop(self):
        if self.lane_state == 1:
            msgx = Float32MultiArray()
            msgx.data = self.center_x

            msgy = Float32MultiArray()
            msgy.data = self.center_y

            self.path_pub_x.publish(msgx)
            self.path_pub_y.publish(msgy)
            self.get_logger().info("published SCNN Data")
            return

        # SCNN unavailable → use fallback path
        if not self.current_path or self.current_index >= len(self.current_path):
            current_sign = self.detection_label
            stop = self.object_detected

            area = check_area(self.current_pos, current_sign, stop)

            if area == 'corner_1':
                if self.previous_area != 'corner_1':
                    self.corner_1_pass_count += 1
                    self.get_logger().info(f"corner_1 entry #{self.corner_1_pass_count}")

                key = 'corner_1_a' if self.corner_1_pass_count == 1 else 'corner_1_b'
                if self.corner_1_pass_count == 2:
                    self.corner_1_pass_count = 0

                file_path = os.path.join(self.config_dir, f"{key}.json")
            elif area != 'normal_drive':
                self.get_logger().info(f"{area} entry")
                file_path = os.path.join(self.config_dir, f"{area}.json")
            else:
                return

            try:
                data = self.load_waypoints(file_path)
                if not data:
                    return
                key = list(data.keys())[0]    # Extract the key, e.g., 'four_lane_no_line'
                self.current_path = interpolate_path(data[key])

            except Exception as e:
                self.get_logger().warn(f"Failed to load or interpolate path for area {area}: {e}")
                return

            self.previous_area = area

        # Continue publishing next point from the current path
        self.publish_path()

def main():
    rclpy.init()
    node = PathSenderNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down PathSenderNode...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
