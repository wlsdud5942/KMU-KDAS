def is_in_area(pose, area):
    x = pose[0]
    y = pose[1]
    return area['x_min'] <= x <= area['x_max'] and area['y_min'] <= y <= area['y_max']

def check_area(pose, sign, stop):
    area_infos = {
        "corner_1": {
            "x_min": -2.070, "x_max": -1.814,
            "y_min": 1.586, "y_max": 1.632,
            
        },
        "corner_2": {
            "x_min": -0.052, "x_max": -0.044,
            "y_min": -1.190, "y_max": -0.845,
            "sign": "Yeid"
            
        },
        "circle_1": {
            "x_min": 2.080, "x_max": 2.352,
            "y_min": 3.126, "y_max": 3.141,
            "sign": "Yeid",
            
        },
        "circle_2": {
            "x_min": 0.874, "x_max": 1.047,
            "y_min": 2.839, "y_max": 3.066,
            "sign": "Yeid",
            
        },
        "four_lane_no_line": {
            "x_min": -0.689, "x_max": 0.678,
            "y_min": 0.667, "y_max": 0.932,
            "sign": "True",
            
        },
        "one_side_no_line": {
            "x_min": 2.083, "x_max": 2.341,
            "y_min": 0.188, "y_max": 0.193,
            "sign": "True",
            
        }
    }

    for area_name, info in area_infos.items():
        if is_in_area(pose, info):
            #if ((info['sign'] == sign or info['sign'] == stop)):
            return area_name
    return "normal_drive"
